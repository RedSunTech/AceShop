<?php

// Heading
$_['heading_title'] = '交易失敗！';

// Text
$_['text_basket'] = '購物車';
$_['text_checkout'] = '結帳';
$_['text_success'] = '交易處理結果';
$_['text_failure'] = '交易失敗';
$_['text_message'] = '<p>交易失敗，原因：%s<br /><br />如果您無法以相同的付款方式完成付款，建議您改用其他付款方式；<br />如果您對交易結果有不清楚的地方，請儘速與我們聯絡，謝謝！！</p>';

?>
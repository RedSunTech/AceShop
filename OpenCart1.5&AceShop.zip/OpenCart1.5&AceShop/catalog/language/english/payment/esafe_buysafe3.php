<?php

$_['text_title'] = '信用卡分期（3期）';
$_['text_payment'] = '支付方式：<font color=\'red\'>信用卡分期（3期）</font>';
$_['text_instruction'] = '支付方式說明：';

$_['text_error'] = '錯誤訊息';
$_['text_failure_notify'] = '交易失敗，原因：';
$_['text_failure_reason_code'] = '（代碼：%s）';
$_['text_interrupt'] = '交易中斷';
$_['text_success_notify'] = '付款成功，交易編號：%s，授權碼：%s，信用卡末四碼：%s';
$_['text_cargono'] = '交貨便代碼：';
$_['text_cargono_query'] = '，<a href="http://myship.7-11.com.tw/cc2b_track.asp?payment_no=%s" target="_blank">查看</a>';
$_['text_shippingmsg'] = '送貨狀態：';
?>
